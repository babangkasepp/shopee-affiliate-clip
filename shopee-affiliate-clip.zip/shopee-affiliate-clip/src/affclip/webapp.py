"""Local web UI (Gradio) for affclip.

Run:
    affclip-web
    # or: python -m affclip.webapp

Opens a browser form: upload product photo, pick style/mood/voice-over,
click Generate, watch progress, download the finished 9:16 clip.

Needs ELEVENLABS_API_KEY + FAL_KEY in your environment / .env.
"""
from __future__ import annotations
import json
import os
import threading
import time
import traceback
import uuid

import gradio as gr

from . import pipeline

# Gradio moved `theme` from Blocks() to launch() in v6 — apply it in the right place.
try:
    _GR_MAJOR = int(gr.__version__.split(".")[0])
except Exception:
    _GR_MAJOR = 4
_GR6 = _GR_MAJOR >= 6

# --------------------------------------------------------------------------- #
# Scene / shot presets keyed by (style, mood)
# --------------------------------------------------------------------------- #
SCENES = {
    ("cinematic", "malam_cozy"): "cozy room at night, warm soft LED glow around the product, "
                                 "fairy-light bokeh, moody cinematic ambiance",
    ("cinematic", "siang"): "bright airy room in daytime, soft natural window light, clean "
                            "aesthetic interior, minimal cinematic ambiance",
    ("handheld", "malam_cozy"): "",   # use photo as-is, POV hand shots
    ("handheld", "siang"): "",
}

SHOTS = {
    "cinematic": [
        "slow cinematic push-in toward the product, light glowing softly, fine particles in the air",
        "smooth glide across the product revealing its details, soft bokeh in the background",
        "slow pull-back revealing the cozy scene around the product, warm inviting atmosphere",
    ],
    "handheld": [
        "POV: a hand picks up the product from a clean desk and holds it up to the camera",
        "POV: the hand slowly rotates the product to show it from different angles, soft studio light",
        "POV: the hand brings the product closer for a detailed close-up, shallow depth of field",
    ],
}

VOICES = {"Bella (cewek, hangat)": "bella", "Rachel (cewek, jernih)": "rachel",
          "Antoni (cowok)": "antoni"}


def suggest_vo(judul: str, harga: str) -> str:
    judul = (judul or "produk ini").strip()
    harga = (harga or "").strip()
    price_line = f"Cuma {harga}! " if harga else ""
    return (f"Wajib punya! {judul} bikin harimu makin gampang dan estetik. "
            f"{price_line}Klik link sekarang, keburu kehabisan!")


def suggest_caption(judul: str, harga: str, harga_coret: str) -> str:
    judul = (judul or "Produk").strip()
    price = ""
    if harga and harga_coret:
        price = f"Harga cuma {harga} (dari {harga_coret}) \U0001f525\n"
    elif harga:
        price = f"Harga cuma {harga} \U0001f525\n"
    return (f"{judul} \u2014 wajib punya! \u2728\n"
            f"\u2705 Kualitas oke\n\u2705 Harga ramah kantong\n\u2705 Bikin estetik\n"
            f"{price}Klik link di bio/komen \U0001f447\n"
            f"#shopeefinds #racunshopee #homedecor #dekorrumah #viral")


# --------------------------------------------------------------------------- #
def _build_config(img_path, style, mood, vo_on, vo_text, voice_label, duration, energy):
    style = "handheld" if style.startswith("Handheld") else "cinematic"
    mood = "siang" if mood.startswith("Siang") else "malam_cozy"
    run_id = uuid.uuid4().hex[:8]
    wd = os.path.join("out", f"web_{run_id}")
    per = max(1, int(round(int(duration) / 3)))
    shots = [{"prompt": p, "duration": min(5, per)} for p in SHOTS[style]]
    return {
        "product_image": img_path,
        "scene_prompt": SCENES[(style, mood)],
        "shots": shots,
        "aspect_ratio": "9:16",
        "vo_text": vo_text.strip() if (vo_on and vo_text) else "",
        "voice": VOICES.get(voice_label, "bella"),
        "backsound": True,
        "energy": "viral" if energy.startswith("Viral") else "calm",
        "out": os.path.join(wd, "final.mp4"),
        "workdir": wd,
    }


def generate(img_path, style, mood, vo_on, vo_text, voice_label, duration, energy,
             progress=gr.Progress()):
    if not img_path:
        raise gr.Error("Upload foto produk dulu ya bro!")
    if not (os.getenv("FAL_KEY")):
        raise gr.Error("FAL_KEY belum di-set. Isi di file .env dulu.")
    if vo_on and not os.getenv("ELEVENLABS_API_KEY"):
        raise gr.Error("ELEVENLABS_API_KEY belum di-set (butuh buat voice-over). "
                       "Matikan VO atau isi key di .env.")

    cfg = _build_config(img_path, style, mood, vo_on, vo_text, voice_label, duration, energy)
    pp = cfg["out"] + ".progress.json"
    err = {}

    def _worker():
        try:
            pipeline.run(cfg)
        except Exception as e:  # noqa
            err["e"] = "".join(traceback.format_exception_only(type(e), e)).strip()

    t = threading.Thread(target=_worker, daemon=True)
    t.start()

    stage_label = {"prep": "Menyiapkan scene \U0001f3a8", "animate": "Bikin video (paling lama) \U0001f3ac",
                   "concat": "Menggabung shot \U0001f9f5", "audio": "Tambah suara + backsound \U0001f3b5",
                   "done": "Selesai! \u2705"}
    progress(0.02, desc="Mulai...")
    seen = 0
    while t.is_alive() or os.path.exists(pp):
        if err:
            break
        if os.path.exists(pp):
            try:
                st = json.load(open(pp))
                events = st.get("events", [])
                if len(events) > seen:
                    seen = len(events)
                    last = events[-1]
                    frac = {"prep": 0.2, "animate": 0.55, "concat": 0.8,
                            "audio": 0.92, "done": 1.0}.get(last["stage"], 0.1)
                    progress(frac, desc=stage_label.get(last["stage"], last["stage"]))
                    if last["stage"] == "done":
                        break
                    if last["stage"] == "error":
                        err["e"] = last.get("msg", "error")
                        break
            except Exception:
                pass
        time.sleep(1.0)
    t.join(timeout=2)

    if err:
        raise gr.Error(f"Gagal generate: {err['e']}")
    if not os.path.exists(cfg["out"]):
        raise gr.Error("Generate selesai tapi file gak ketemu. Cek log terminal.")
    return cfg["out"]


# --------------------------------------------------------------------------- #
def build_ui():
    blocks_kwargs = {"title": "Shopee Affiliate Clip"}
    if not _GR6:
        blocks_kwargs["theme"] = gr.themes.Soft()
    with gr.Blocks(**blocks_kwargs) as demo:
        gr.Markdown("# \U0001f3ac Shopee Affiliate Clip\n"
                    "Ubah *foto produk* jadi video promo vertikal 9:16 + voice-over + backsound. "
                    "Produk tetap 100% asli, cuma scene & gerakan yang dibikin AI.")
        with gr.Row():
            with gr.Column(scale=1):
                img = gr.Image(type="filepath", label="Foto produk", height=240)
                judul = gr.Textbox(label="Judul produk (buat VO & caption)",
                                   placeholder="Jam Dinding Bunga LED Aesthetic")
                with gr.Row():
                    harga = gr.Textbox(label="Harga", placeholder="Rp34.900")
                    harga_coret = gr.Textbox(label="Harga coret (opsional)", placeholder="Rp90.000")
                style = gr.Radio(["Cinematic (dekor/hiasan dinding)", "Handheld (gadget kecil)"],
                                 value="Cinematic (dekor/hiasan dinding)", label="Gaya")
                mood = gr.Radio(["Malam cozy", "Siang cerah"], value="Malam cozy", label="Mood")
                with gr.Row():
                    vo_on = gr.Checkbox(value=True, label="Voice-over ON")
                    voice = gr.Dropdown(list(VOICES.keys()), value="Bella (cewek, hangat)",
                                        label="Suara")
                vo_text = gr.Textbox(label="Teks voice-over (auto, bisa diedit)", lines=3)
                with gr.Row():
                    duration = gr.Slider(5, 20, value=15, step=5, label="Durasi (detik)")
                    energy = gr.Radio(["Viral (pad+beat)", "Calm (pad only)"],
                                      value="Viral (pad+beat)", label="Backsound")
                btn = gr.Button("\U0001f680 Generate Video", variant="primary", size="lg")
            with gr.Column(scale=1):
                out_video = gr.Video(label="Hasil (9:16)", height=420)
                caption = gr.Textbox(label="Caption FB / Reels (siap copy)", lines=8)

        # auto-fill VO + caption suggestions
        def _refresh(j, h, hc):
            return suggest_vo(j, h), suggest_caption(j, h, hc)
        for comp in (judul, harga, harga_coret):
            comp.change(_refresh, [judul, harga, harga_coret], [vo_text, caption])

        btn.click(generate,
                  [img, style, mood, vo_on, vo_text, voice, duration, energy],
                  [out_video])
        gr.Markdown("_Generate makan beberapa menit (manggil API video + voice) dan pakai "
                    "kuota API lo. Test pakai durasi 5 detik dulu._")
    return demo


def main():
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except Exception:
        pass
    os.makedirs("out", exist_ok=True)
    launch_kwargs = {"inbrowser": True, "server_name": "127.0.0.1"}
    if _GR6:
        launch_kwargs["theme"] = gr.themes.Soft()
    build_ui().launch(**launch_kwargs)


if __name__ == "__main__":
    main()
